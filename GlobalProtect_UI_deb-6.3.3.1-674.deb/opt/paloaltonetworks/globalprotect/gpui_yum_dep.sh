#!/bin/bash

# Determine Linux Distro and Version
. /etc/os-release

linux_ver=${VERSION_ID:0:1}
echo "Linux Version: $ID $linux_ver"

# Determine package manager command
pkg_mgr_cmd="yum"
if which dnf >/dev/null 2>&1; then
    pkg_mgr_cmd="dnf"
elif which yum >/dev/null 2>&1; then
    pkg_mgr_cmd="yum"
else
    echo "Error: No supported package manager found (yum/dnf)"
    exit 1
fi

# Install EPEL Repository
if [ "$ID" = "centos" ]; then
    sudo $pkg_mgr_cmd -y install epel-release
elif [ "$ID" = "rhel" ]; then
    if [ "$linux_ver" = "7" ]; then
        sudo $pkg_mgr_cmd -y install https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
    elif [ "$linux_ver" = "8" ]; then
        sudo $pkg_mgr_cmd -y install https://dl.fedoraproject.org/pub/epel/epel-release-latest-8.noarch.rpm
    elif [ "$linux_ver" = "9" ]; then
        sudo $pkg_mgr_cmd -y install https://dl.fedoraproject.org/pub/epel/epel-release-latest-9.noarch.rpm
    else
	echo "Error: Unsupported Linux version: $linux_ver"
    fi
else
    echo "Error: Unrecognized OS: $ID"
    exit
fi

# Install Qt5 WebEngine (EPEL Repository) - Updated for QWebEngine
echo "$pkg_mgr_cmd: Installing Qt5 WebEngine and wmctrl..."
sudo $pkg_mgr_cmd -y install qt5-qtwebengine wmctrl
